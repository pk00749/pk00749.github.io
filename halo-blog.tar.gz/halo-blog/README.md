# Halo Blog Theme

移动端优化的 Halo 2.x 博客主题，支持 AI 对话功能。

## 特性

- 📱 **移动端优化** - 响应式设计，完美适配各种屏幕尺寸
- 🤖 **AI 对话** - 支持集成 OpenAI/Anpatible 等 AI API
- 🎨 **现代设计** - 简洁优雅的 UI 设计
- ⚡ **轻量快速** - 纯 HTML/CSS/JS，无冗余依赖

## 安装

1. 下载主题包
2. 在 Halo 后台 -> 外观 -> 主题 -> 安装
3. 激活主题并配置

## 配置

### 通用设置
- Logo 图片
- 博客描述
- 头像

### AI 对话设置
- 启用/禁用 AI 对话
- API 地址 (支持 OpenAI 兼容接口)
- API 密钥
- 选择模型
- 系统提示词

### 社交链接
- GitHub
- Twitter
- 邮箱

## AI 对话配置

主题支持对接以下 API：

### OpenAI
- API 地址: `https://api.openai.com/v1/chat/completions`
- 模型: `gpt-3.5-turbo` / `gpt-4`

### Anthropic (Claude)
- API 地址: `https://api.anthropic.com/v1/messages`
- 模型: `claude-3-sonnet-20240229`

### 自定义 API
支持任何 OpenAI 兼容的 API 服务。

## 文件结构

```
halo-blog/
├── templates/
│   ├── assets/
│   │   ├── css/
│   │   │   ├── main.css      # 主样式
│   │   │   ├── mobile.css    # 移动端样式
│   │   │   └── chat.css      # 聊天页面样式
│   │   └── js/
│   │       ├── main.js       # 主要脚本
│   │       └── chatbot.js     # AI 对话脚本
│   ├── index.html            # 首页
│   ├── post.html             # 文章详情
│   ├── category.html         # 分类页
│   ├── tag.html              # 标签页
│   ├── tags.html             # 标签列表
│   ├── archives.html         # 归档页
│   └── chat.html             # AI 对话页
├── theme.yaml                # 主题配置
├── settings.yaml            # 主题设置
└── SPEC.md                  # 项目规范
```

## 开发

### 本地开发

```bash
# 克隆仓库
git clone https://github.com/pk00749/halo-blog.git

# 进入目录
cd halo-blog

# 创建新分支进行开发
git checkout -b feature/your-feature
```

### 规范

参考 `SPEC.md` 了解项目开发规范。

## 许可证

MIT License
