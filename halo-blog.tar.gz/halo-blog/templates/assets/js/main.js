/* ===================================
   Halo Blog - 主脚本
   =================================== */

document.addEventListener('DOMContentLoaded', function() {
  // 移动端导航
  initMobileNav();
  
  // 图片懒加载
  initLazyLoad();
  
  // 代码高亮 (如需要)
  initCodeHighlight();
  
  // 搜索功能
  initSearch();
});

/**
 * 移动端导航
 */
function initMobileNav() {
  const toggle = document.querySelector('.mobile-nav-toggle');
  const mobileNav = document.querySelector('.mobile-nav');
  
  if (!toggle || !mobileNav) return;
  
  toggle.addEventListener('click', function() {
    mobileNav.classList.toggle('active');
    document.body.classList.toggle('nav-open');
    
    // 更新图标
    const icon = toggle.querySelector('svg');
    if (mobileNav.classList.contains('active')) {
      icon.innerHTML = '<path d="M6 18L18 6M6 6l12 12"/>'; // X icon
    } else {
      icon.innerHTML = '<path d="M4 6h16M4 12h16M4 18h16"/>'; // Menu icon
    }
  });
  
  // 点击外部关闭
  document.addEventListener('click', function(e) {
    if (!mobileNav.contains(e.target) && !toggle.contains(e.target)) {
      mobileNav.classList.remove('active');
      document.body.classList.remove('nav-open');
    }
  });
}

/**
 * 图片懒加载
 */
function initLazyLoad() {
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src || img.src;
          img.classList.remove('lazy');
          observer.unobserve(img);
        }
      });
    }, {
      rootMargin: '50px 0px'
    });
    
    document.querySelectorAll('').forEach(functionimg[data-src](img) {
      observer.observe(img);
    });
  }
}

/**
 * 代码高亮 (简单实现)
 */
function initCodeHighlight() {
  // 如需更强大的高亮，可集成 Prism.js 或 Highlight.js
  document.querySelectorAll('pre code').forEach(function(block) {
    block.classList.add('hljs');
  });
}

/**
 * 搜索功能
 */
function initSearch() {
  const searchInput = document.getElementById('search-input');
  const searchResults = document.getElementById('search-results');
  
  if (!searchInput || !searchResults) return;
  
  let searchTimer;
  
  searchInput.addEventListener('input', function() {
    clearTimeout(searchTimer);
    const query = this.value.trim();
    
    if (query.length < 2) {
      searchResults.style.display = 'none';
      return;
    }
    
    searchTimer = setTimeout(function() {
      performSearch(query);
    }, 300);
  });
  
  // 点击搜索按钮触发
  const searchBtn = document.getElementById('search-btn');
  if (searchBtn) {
    searchBtn.addEventListener('click', function() {
      const query = searchInput.value.trim();
      if (query) performSearch(query);
    });
  }
}

function performSearch(query) {
  const searchResults = document.getElementById('search-results');
  if (!searchResults) return;
  
  // 显示加载状态
  searchResults.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
  searchResults.style.display = 'block';
  
  // 发起搜索请求 - Halo 提供了 /api/content/search 接口
  fetch('/api/content/search?keyword=' + encodeURIComponent(query))
    .then(function(response) {
      return response.json();
    })
    .then(function(data) {
      renderSearchResults(data);
    })
    .catch(function(error) {
      searchResults.innerHTML = '<div class="text-center text-muted">搜索失败，请稍后重试</div>';
    });
}

function renderSearchResults(results) {
  const searchResults = document.getElementById('search-results');
  if (!results || results.length === 0) {
    searchResults.innerHTML = '<div class="text-center text-muted">未找到相关结果</div>';
    return;
  }
  
  const html = results.slice(0, 10).map(function(post) {
    return '<div class="post-card">' +
      '<h3 class="post-card-title"><a href="' + post.url + '">' + post.title + '</a></h3>' +
      '<p class="post-card-excerpt">' + (post.excerpt || '') + '</p>' +
      '</div>';
  }).join('');
  
  searchResults.innerHTML = html;
}

/**
 * 工具函数
 */
window.haloBlog = {
  // 格式化日期
  formatDate: function(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) return '刚刚';
    if (minutes < 60) return minutes + ' 分钟前';
    if (hours < 24) return hours + ' 小时前';
    if (days < 30) return days + ' 天前';
    
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  },
  
  // 显示提示
  showToast: function(message, duration) {
    duration = duration || 2000;
    
    let toast = document.querySelector('.toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'toast';
      toast.style.cssText = 'position:fixed;bottom:80px;left:50%;transform:translateX(-50%);background:#333;color:#fff;padding:12px 24px;border-radius:8px;font-size:14px;z-index:1000;opacity:0;transition:opacity 0.3s';
      document.body.appendChild(toast);
    }
    
    toast.textContent = message;
    toast.style.opacity = '1';
    
    setTimeout(function() {
      toast.style.opacity = '0';
    }, duration);
  }
};
