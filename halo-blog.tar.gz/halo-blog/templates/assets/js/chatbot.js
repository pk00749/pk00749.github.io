/* ===================================
   Halo Blog - AI Chatbot 脚本
   =================================== */

(function() {
  'use strict';
  
  // 配置
  const CONFIG = {
    enabled: true,
    apiEndpoint: '',
    apiKey: '',
    model: 'gpt-3.5-turbo',
    systemPrompt: '你是一个友好、有帮助的博客助手，擅长回答技术问题和讨论文章内容。'
  };
  
  // 状态
  let isOpen = false;
  let messages = [];
  let isLoading = false;
  
  // 从 localStorage 加载配置和历史
  function loadState() {
    try {
      const saved = localStorage.getItem('halo-chatbot');
      if (saved) {
        const data = JSON.parse(saved);
        messages = data.messages || [];
        CONFIG.enabled = data.config?.enabled ?? CONFIG.enabled;
        CONFIG.apiEndpoint = data.config?.apiEndpoint || CONFIG.apiEndpoint;
        CONFIG.apiKey = data.config?.apiKey || CONFIG.apiKey;
        CONFIG.model = data.config?.model || CONFIG.model;
        CONFIG.systemPrompt = data.config?.systemPrompt || CONFIG.systemPrompt;
      }
    } catch (e) {
      console.error('Failed to load chatbot state:', e);
    }
  }
  
  function saveState() {
    try {
      localStorage.setItem('halo-chatbot', JSON.stringify({
        messages: messages.slice(-50), // 保存最近50条
        config: CONFIG
      }));
    } catch (e) {
      console.error('Failed to save chatbot state:', e);
    }
  }
  
  // 创建 DOM 元素
  function createElements() {
    // 浮动按钮
    const fab = document.createElement('div');
    fab.id = 'chat-fab';
    fab.className = 'chat-fab';
    fab.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>';
    fab.addEventListener('click', toggleChat);
    document.body.appendChild(fab);
    
    // 聊天窗口
    const chatWindow = document.createElement('div');
    chatWindow.id = 'chat-window';
    chatWindow.className = 'chat-window';
    chatWindow.innerHTML = getChatWindowHTML();
    document.body.appendChild(chatWindow);
    
    // 绑定事件
    bindEvents();
  }
  
  function getChatWindowHTML() {
    return '' +
      '<div class="chat-header">' +
        '<div class="chat-title">' +
          '<span class="chat-avatar">🤖</span>' +
          '<span>AI 助手</span>' +
        '</div>' +
        '<button class="chat-close" id="chat-close">' +
          '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>' +
        '</button>' +
      '</div>' +
      '<div class="chat-messages" id="chat-messages"></div>' +
      '<div class="chat-input-wrap">' +
        '<input type="text" class="chat-input" id="chat-input" placeholder="发送消息..." autocomplete="off">' +
        '<button class="chat-send" id="chat-send">' +
          '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>' +
        '</button>' +
      '</div>';
  }
  
  function bindEvents() {
    const closeBtn = document.getElementById('chat-close');
    const sendBtn = document.getElementById('chat-send');
    const input = document.getElementById('chat-input');
    
    if (closeBtn) closeBtn.addEventListener('click', toggleChat);
    
    if (sendBtn) sendBtn.addEventListener('click', sendMessage);
    
    if (input) {
      input.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          sendMessage();
        }
      });
    }
    
    // 点击外部关闭
    document.addEventListener('click', function(e) {
      const fab = document.getElementById('chat-fab');
      const window = document.getElementById('chat-window');
      if (isOpen && !fab.contains(e.target) && !window.contains(e.target)) {
        toggleChat();
      }
    });
  }
  
  // 切换聊天窗口
  function toggleChat() {
    isOpen = !isOpen;
    const chatWindow = document.getElementById('chat-window');
    const fab = document.getElementById('chat-fab');
    
    if (isOpen) {
      chatWindow.classList.add('active');
      fab.classList.add('hidden');
      renderMessages();
      
      // 自动聚焦输入框
      setTimeout(function() {
        document.getElementById('chat-input').focus();
      }, 100);
    } else {
      chatWindow.classList.remove('active');
      fab.classList.remove('hidden');
    }
  }
  
  // 渲染消息
  function renderMessages() {
    const container = document.getElementById('chat-messages');
    if (!container) return;
    
    if (messages.length === 0) {
      container.innerHTML = '<div class="chat-message bot">' +
        '<div class="message-content">你好！我是AI助手，有什么可以帮助你的吗？</div>' +
        '</div>';
      return;
    }
    
    container.innerHTML = messages.map(function(msg) {
      return '<div class="chat-message ' + msg.role + '">' +
        '<div class="message-content">' + escapeHtml(msg.content) + '</div>' +
        '</div>';
    }).join('');
    
    // 滚动到底部
    container.scrollTop = container.scrollHeight;
  }
  
  // 发送消息
  async function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    
    if (!message || isLoading) return;
    
    // 检查配置
    if (!CONFIG.apiEndpoint || !CONFIG.apiKey) {
      showConfigPrompt();
      return;
    }
    
    // 添加用户消息
    messages.push({ role: 'user', content: message });
    input.value = '';
    renderMessages();
    
    // 显示加载状态
    isLoading = true;
    showLoading();
    
    try {
      const response = await callAPI(message);
      
      messages.push({ role: 'bot', content: response });
      saveState();
      renderMessages();
    } catch (error) {
      messages.push({ role: 'bot', content: '抱歉，我遇到了一些问题: ' + error.message });
      renderMessages();
    } finally {
      isLoading = false;
      hideLoading();
    }
  }
  
  // 调用 AI API
  async function callAPI(message) {
    const history = messages.slice(-10).map(function(m) {
      return { role: m.role === 'bot' ? 'assistant' : m.role, content: m.content };
    });
    
    const payload = {
      model: CONFIG.model,
      messages: [
        { role: 'system', content: CONFIG.systemPrompt },
        ...history,
        { role: 'user', content: message }
      ],
      stream: false
    };
    
    const response = await fetch(CONFIG.apiEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + CONFIG.apiKey
      },
      body: JSON.stringify(payload)
    });
    
    if (!response.ok) {
      throw new Error('API 请求失败: ' + response.status);
    }
    
    const data = await response.json();
    return data.choices?.[0]?.message?.content || '无响应';
  }
  
  // 显示配置提示
  function showConfigPrompt() {
    const container = document.getElementById('chat-messages');
    if (!container) return;
    
    container.innerHTML += '<div class="chat-message bot">' +
      '<div class="message-content">请先配置 AI API！在主题设置中添加 API 地址和密钥。</div>' +
      '</div>';
    container.scrollTop = container.scrollHeight;
  }
  
  // 显示加载
  function showLoading() {
    const container = document.getElementById('chat-messages');
    if (!container) return;
    
    const loading = document.createElement('div');
    loading.id = 'chat-loading';
    loading.className = 'chat-message bot loading';
    loading.innerHTML = '<div class="message-content"><span class="typing"><span>.</span><span>.</span><span>.</span></span></div>';
    container.appendChild(loading);
    container.scrollTop = container.scrollHeight;
  }
  
  // 隐藏加载
  function hideLoading() {
    const loading = document.getElementById('chat-loading');
    if (loading) loading.remove();
  }
  
  // HTML 转义
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
  
  // 初始化
  function init() {
    loadState();
    
    // 检查是否启用
    if (!CONFIG.enabled) {
      const fab = document.getElementById('chat-fab');
      if (fab) fab.style.display = 'none';
      return;
    }
    
    createElements();
  }
  
  // 页面加载完成后初始化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  
  // 暴露全局方法供外部调用
  window.haloChatbot = {
    open: function() {
      if (!isOpen) toggleChat();
    },
    close: function() {
      if (isOpen) toggleChat();
    },
    setConfig: function(config) {
      Object.assign(CONFIG, config);
      saveState();
    }
  };
})();
