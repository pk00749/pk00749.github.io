/* ===================================
   Halo Blog - 独立聊天页面脚本
   =================================== */

(function() {
  'use strict';
  
  // 配置
  const CONFIG = {
    apiEndpoint: /*[[${theme.config.chatbot.apiEndpoint}]]*/ '',
    apiKey: /*[[${theme.config.chatbot.apiKey}]]*/ '',
    model: /*[[${theme.config.chatbot.model}]]*/ 'gpt-3.5-turbo',
    systemPrompt: /*[[${theme.config.chatbot.systemPrompt}]]*/ '你是一个友好、有帮助的博客助手。'
  };
  
  // 状态
  let messages = [];
  let isLoading = false;
  
  // DOM 元素
  const messagesContainer = document.getElementById('chat-messages');
  const input = document.getElementById('chat-input');
  const sendBtn = document.getElementById('chat-send');
  
  // 初始化
  function init() {
    // 从 localStorage 加载历史
    loadHistory();
    
    // 绑定事件
    bindEvents();
    
    // 渲染历史消息
    renderMessages();
  }
  
  function bindEvents() {
    // 发送按钮
    if (sendBtn) {
      sendBtn.addEventListener('click', sendMessage);
    }
    
    // 输入框回车发送
    if (input) {
      input.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          sendMessage();
        }
      });
      
      // 自动调整高度
      input.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
      });
    }
  }
  
  // 加载历史
  function loadHistory() {
    try {
      const saved = localStorage.getItem('halo-chatbot');
      if (saved) {
        const data = JSON.parse(saved);
        messages = data.messages || [];
      }
    } catch (e) {
      console.error('Failed to load history:', e);
    }
  }
  
  // 保存历史
  function saveHistory() {
    try {
      localStorage.setItem('halo-chatbot', JSON.stringify({
        messages: messages.slice(-50)
      }));
    } catch (e) {
      console.error('Failed to save history:', e);
    }
  }
  
  // 渲染消息
  function renderMessages() {
    if (!messagesContainer) return;
    
    if (messages.length === 0) {
      messagesContainer.innerHTML = '<div class="chat-message bot">' +
        '<div class="message-avatar">🤖</div>' +
        '<div class="message-content">👋 你好！我是AI助手，有什么可以帮助你的吗？</div>' +
        '</div>';
      return;
    }
    
    messagesContainer.innerHTML = messages.map(function(msg) {
      const avatar = msg.role === 'user' ? '👤' : '🤖';
      return '<div class="chat-message ' + msg.role + '">' +
        '<div class="message-avatar">' + avatar + '</div>' +
        '<div class="message-content">' + escapeHtml(msg.content) + '</div>' +
        '</div>';
    }).join('');
    
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }
  
  // 发送消息
  async function sendMessage() {
    const message = input.value.trim();
    if (!message || isLoading) return;
    
    // 检查配置
    if (!CONFIG.apiEndpoint || !CONFIG.apiKey) {
      showConfigPrompt();
      return;
    }
    
    // 添加用户消息
    messages.push({ role: 'user', content: message });
    input.value = '';
    input.style.height = 'auto';
    renderMessages();
    
    // 显示加载
    isLoading = true;
    showLoading();
    
    try {
      const response = await callAPI(message);
      messages.push({ role: 'bot', content: response });
      saveHistory();
      renderMessages();
    } catch (error) {
      messages.push({ role: 'bot', content: '抱歉，我遇到了一些问题: ' + error.message });
      renderMessages();
    } finally {
      isLoading = false;
      hideLoading();
    }
  }
  
  // 调用 API
  async function callAPI(message) {
    const history = messages.slice(-10).map(function(m) {
      return { role: m.role === 'bot' ? 'assistant' : m.role, content: m.content };
    });
    
    const payload = {
      model: CONFIG.model,
      messages: [
        { role: 'system', content: CONFIG.systemPrompt },
        ...history,
        { role: 'user', content: message }
      ],
      stream: false
    };
    
    const response = await fetch(CONFIG.apiEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + CONFIG.apiKey
      },
      body: JSON.stringify(payload)
    });
    
    if (!response.ok) {
      throw new Error('API请求失败: ' + response.status);
    }
    
    const data = await response.json();
    return data.choices?.[0]?.message?.content || '无响应';
  }
  
  // 显示配置提示
  function showConfigPrompt() {
    messages.push({ role: 'bot', content: '⚠️ 请先在主题设置中配置 AI API 地址和密钥。' });
    renderMessages();
  }
  
  // 显示加载
  function showLoading() {
    if (!messagesContainer) return;
    const loading = document.createElement('div');
    loading.id = 'chat-loading';
    loading.className = 'chat-message bot loading';
    loading.innerHTML = '<div class="message-avatar">🤖</div><div class="message-content"><span>.</span><span>.</span><span>.</span></div>';
    messagesContainer.appendChild(loading);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }
  
  // 隐藏加载
  function hideLoading() {
    const loading = document.getElementById('chat-loading');
    if (loading) loading.remove();
  }
  
  // HTML 转义
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
  
  // 启动
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
