# Halo Blog 项目规范 (SPEC.md)

## 1. 项目概述

- **项目名称**: halo-blog
- **类型**: Halo 2.x 博客主题 + AI Chatbot 插件
- **核心功能**: 移动端优化的博客主题，支持文章阅读和AI对话功能
- **目标用户**: 移动端用户，内容创作者

## 2. 技术架构

### 2.1 Halo 主题结构
```
halo-blog/
├── templates/
│   ├── assets/
│   │   ├── css/
│   │   │   ├── main.css        # 主样式
│   │   │   └── mobile.css      # 移动端适配
│   │   └── js/
│   │       ├── main.js         # 主要交互
│   │       └── chatbot.js      # AI聊天功能
│   ├── index.html              # 首页/文章列表
│   ├── post.html               # 文章详情
│   ├── page.html               # 独立页面
│   ├── tag.html                # 标签页
│   ├── category.html           # 分类页
│   └── chat.html               # AI对话页面
├── theme.yaml                  # 主题配置
├── settings.yaml               # 主题设置
└── README.md
```

### 2.2 技术栈
- **模板引擎**: Thymeleaf (Halo 内置)
- **样式**: CSS3 + Flexbox/Grid
- **JavaScript**: Vanilla JS (轻量级)
- **AI Chatbot**: API 集成 (OpenAI/Anthropic 兼容)

## 3. 功能规范

### 3.1 文章系统
- [ ] 文章列表分页展示
- [ ] 文章详情页 (支持 Markdown 渲染)
- [ ] 分类目录导航
- [ ] 标签系统
- [ ] 文章搜索
- [ ] 评论区 (Halo 内置)

### 3.2 AI Chatbot
- [ ] 独立聊天页面
- [ ] 浮动聊天窗口 (移动端)
- [ ] 流式响应展示
- [ ] 会话历史 (本地存储)
- [ ] 配置化 API 端点

### 3.3 移动端适配
- [ ] 响应式布局 (320px - 1920px)
- [ ] 触摸优化
- [ ] 移动端导航菜单
- [ ] 字体大小适配
- [ ] 图片懒加载

## 4. UI/UX 规范

### 4.1 颜色系统
```css
:root {
  --primary: #2563eb;        /* 主色 - 蓝色 */
  --primary-dark: #1d4ed8;   /* 主色深 */
  --secondary: #64748b;      /* 次要色 */
  --accent: #f59e0b;         /* 强调色 */
  --background: #ffffff;     /* 背景 */
  --surface: #f8fafc;         /* 卡片表面 */
  --text: #1e293b;           /* 主文字 */
  --text-secondary: #64748b; /* 次要文字 */
  --border: #e2e8f0;         /* 边框 */
  --code-bg: #f1f5f9;        /* 代码背景 */
}
```

### 4.2 字体
- **标题**: "PingFang SC", "Microsoft YaHei", sans-serif
- **正文**: "PingFang SC",i", sans-serif "Microsoft YaHe
- **代码**: "SF Mono", "Consolas", monospace

### 4.3 布局
- **移动端 单栏768px)**: (< ，宽度 100%
- **平板 (768px - 1024px)**: 单栏，宽度 90%
-1024px) **桌面 (> 1200px，居**: 最大宽度 中

### #### 组件

4.4 导航栏
- 固定顶部
-  Logo + 标题移动
-  端: 汉堡菜单
桌面端-  : 完整链接

#### 文章导航卡片
- 标题 + 摘要 + 日期 +  悬停效果分类标签
- + 阴影
: 轻微上浮- 移动端: 全卡片

#### Chat宽度bot 组件
- 浮动按钮 (右下角)
- 展开式聊天窗口
- 输入框 + 发送按钮
- 消息气泡 (用户/AI 区分)

## 5. API 集成

### 5.1 AI Chatbot API
```javascript
// 配置项 (settings.yaml)
chatbot:
  apiEndpoint: ""      // API 地址
  apiKey: ""           // API 密钥
  model: "gpt-3.5-turbo"  // 模型
  systemPrompt: "你是一个有帮助的博客助手"
```

### 5.2 请求格式
```javascript
POST /api/chat
{
  "message": "用户消息",
  "history": ["对话历史"]
}
```

## 6. 主题配置 (theme.yaml)

```yaml
id: com.halo-blog.theme
name: Halo Blog
description: 移动端优化的博客主题，支持AI对话
version: 1.0.0
author:
  name: Your Name
  website: https://yourdomain.com
```

## 7. 设置项 (settings.yaml)

```yaml
sections:
  - name: general
    label: 通用设置
    items:
      - name: logo
        label: Logo
        type: attachment
      - name: description
        label: 博客描述
        type: text

  - name: chatbot
    label: AI 对话设置
    items:
      - name: apiEndpoint
        label: API 地址
        type: text
      - name: apiKey
        label: API 密钥
        type: secret
      - name: model
        label: 模型
        type: select
        options:
          - gpt-3.5-turbo
          - gpt-4
          - claude-3-sonnet
```

## 8. 开发里程碑 (每5小时为一个阶段)

### Phase 1: 基础主题结构 + 移动端布局 (5小时) ✅ 已完成
- [x] 创建项目目录结构
- [x] 编写 theme.yaml 和 settings.yaml
- [x] 编写主样式 main.css
- [x] 编写移动端样式 mobile.css
- [x] 编写主脚本 main.js
- [x] 编写 index.html 首页模板

### Phase 2: 文章系统 (5小时) ✅ 已完成
- [x] 编写 post.html 文章详情页
- [x] 编写 category.html 分类页
- [x] 编写 tag.html 标签页
- [x] 完善分页和导航

### Phase 3: AI Chatbot 核心功能 (5小时) 🔄 进行中
- [x] 编写 chatbot.js 浮动聊天功能
- [x] 编写 chat.html 独立对话页面
- [x] 编写 chat.css 聊天页面样式
- [x] 编写 chatbot-page.js 独立页面脚本

### Phase 4: 完善与优化 (5小时) ✅ 已完成
- [x] 添加代码高亮 (Prism.js/Highlight.js)
- [x] SEO meta 标签优化
- [x] tags.html 标签列表页
- [x] archives.html 归档页
- [x] README 文档
- [ ] GitHub 推送 (网络问题，可手动执行)

---

## 待手动执行

```bash
cd halo-blog
git push -u origin main
```

或访问: https://github.com/pk00749/halo-blog
- [ ] 编写 chat.html 独立对话页面
- [ ] 添加浮动聊天窗口样式
- [ ] 对接 API 配置

### Phase 4: 完善与优化 (5小时)
- [ ] 添加代码高亮
- [ ] SEO 优化
- [ ] 性能优化
- [ ] 提交到 GitHub

## 9. 参考资源

- [Halo 官方文档](https://docs.halo.run)
- [Halo Theme GitHub](https://github.com/halo-dev/halo)
- [Halo 主题开发指南](https://docs.halo.run/developer-guide/theme/structure)

---

**创建日期**: 2026-03-03
**最后更新**: 2026-03-03
**版本**: 1.0.0
